jQuery.fn.eddGitAdminModal = function ( action, options ) {
	if ( 'object' === typeof action ) {
		options = action;
	}

	var defaults = { 'title': '', 'buttons': false };

	if ( 'undefined' === typeof options ) {
		options = jQuery( this ).data( 'eddGitAdminModal' );
		if ( 'undefined' === typeof options ) {
			// Merge our default options with the options sent
			options = jQuery.extend( defaults, options );
		}
	} else {
		// Merge our default options with the options sent
		options = jQuery.extend( defaults, options );
	}

	// Set our data with the current options
	jQuery( this ).data( 'eddGitAdminModal', options );

	jQuery( this ).hide();
	jQuery( '#edd-git-admin-modal-content' ).html( this.html() );

	jQuery( '#edd-git-modal-title' ).html( options.title );

	if ( options.buttons ) {
		jQuery( options.buttons ).hide();
		var buttons = jQuery( options.buttons ).html();
		jQuery( '#modal-contents-wrapper' ).find( '.submitbox' ).html( buttons );
		jQuery( '#edd-git-admin-modal-content' ).addClass( 'admin-modal-inside' );
		jQuery( '#modal-contents-wrapper' ).find( '.submitbox' ).show();
	} else {
		jQuery( '#edd-git-admin-modal-content' ).removeClass( 'admin-modal-inside' );
		jQuery( '#modal-contents-wrapper' ).find( '.submitbox' ).hide();
	}

	if ( 'close' == action ) {
		jQuery.fn.eddGitAdminModal.close();
	} else if ( 'open' == action ) {
		jQuery.fn.eddGitAdminModal.open();
	}

	jQuery( document ).on( 'click', '.modal-close', function ( e ) {
		e.preventDefault();
		jQuery.fn.eddGitAdminModal.close();
	} );

};

jQuery.fn.eddGitAdminModal.close = function () {
	jQuery( '#edd-git-admin-modal-backdrop' ).hide();
	jQuery( '#edd-git-admin-modal-wrap' ).hide();
	jQuery( document ).triggerHandler( 'eddGitAdminModalClose' );
};

jQuery.fn.eddGitAdminModal.open = function () {
	jQuery( '#edd-git-admin-modal-backdrop' ).show();
	jQuery( '#edd-git-admin-modal-wrap' ).show();
	jQuery( document ).triggerHandler( 'eddGitAdminModalOpen' );
};


( function ( document, $, undefined ) {

	var eddGit = {
		gitHub: {
			authorize: function () {
				if ( this.checkKeys() ) { // Make sure that our Client ID and Client Key aren't empty
					// Remove any errors we have already set.
					$( '.git-edd-error' ).remove();
					$( '#edd-git-github-spinner' ).show();
					var client_id = $( '#edd_settings\\[gh_clientid\\]' ).val();
					var client_secret = $( '#edd_settings\\[gh_clientsecret\\]' ).val();
					this.requestToken( client_id, client_secret );
				}
			},
			checkKeys: function () {
				var ret = true;
				if ( $( '#edd_settings\\[gh_clientid\\]' ).val() == '' ) {
					var error = '<div class="notice notice-error git-edd-error"><p>' + gitUpdater.invalidID + '</p></div>';
					$( '#edd_settings\\[gh_clientid\\]' ).after( error );
					ret = false;
				}

				if ( $( '#edd_settings\\[gh_clientsecret\\]' ).val() == '' ) {
					var error = '<div class="notice notice-error git-edd-error"><p>' + gitUpdater.invalidSecret + '</p></div>';
					$( '#edd_settings\\[gh_clientsecret\\]' ).after( error );
					ret = false;
				}

				return ret;
			},
			requestToken: function ( client_id, client_secret ) {
				$.post( ajaxurl, { client_id: client_id, client_secret: client_secret, action: 'edd_git_gh_request_token' }, function ( response ) {
					window.location = response;
				} );
			},
			disconnect: function () {
				$( '#edd-git-github-spinner' ).show();
				$.post( ajaxurl, { action: 'edd_git_gh_disconnect' }, function ( response ) {
					$( '#edd-git-github-spinner' ).hide();
					$( '.edd-git-github-connected' ).hide();
					$( '.edd-git-github-disconnected' ).show();
				} );
			}
		},
		editDownload: {
			useGit: gitUpdater.useGit,
			currentTag: gitUpdater.currentTag,
			currentGitUrl: gitUpdater.currentGitUrl,
			fetchStatus: 'clean',
			init: function () {
				this.fetchRepos();

				$( '.git-repo' ).chosen( {
					inherit_option_classes: true,
					include_group_label_in_selected: true,
					width: 200,
				} );
				$( '.git-tag' ).chosen( {
					no_results_text: gitUpdater.noTags,
					placeholder_text_single: gitUpdater.placeholderTags,
					width: 125,
				} );

				if ( 1 == this.useGit ) {
					this.setUpgradeFile();
				}
				$( '.edd-git-fetch-prompt' ).eddGitAdminModal( { title: '', buttons: '.edd-git-fetch-prompt-buttons' } );
			},
			changeFetchStatus: function ( status ) {
				this.fetchStatus = status;
				$( '.edd-git-update .edd-git-text' ).text( gitUpdater.downloadButton[ status ] );
				if ( 'dirty' == status ) {
					$( '.edd-git-update' ).attr( 'disabled', false );
					$( '.edd-git-update' ).removeClass( 'button-secondary' );
					$( '.edd-git-update' ).addClass( 'button-primary' );
				} else if ( 'clean' == status ) {
					$( '.edd-git-update' ).attr( 'disabled', false );
					$( '.edd-git-update' ).removeClass( 'button-primary' );
					$( '.edd-git-update' ).addClass( 'button-secondary' );
				} else if ( 'none' == status ) {
					$( '.edd-git-update' ).attr( 'disabled', true );
					$( '.edd-git-update' ).removeClass( 'button-primary' );
					$( '.edd-git-update' ).addClass( 'button-secondary' );
				}
			},
			changeTag: function ( tag ) {
				var repo = $( '.git-repo option:selected' ).data( 'slug' );

				if ( '' == tag || null == tag ) {
					this.changeFetchStatus( 'none' );
					return false;
				}
				if ( this.currentTag == tag && this.currentGitUrl == $( '.git-repo' ).val() ) {
					this.changeFetchStatus( 'clean' );
				} else {
					this.changeFetchStatus( 'dirty' );
				}

				if ( 'clean' !== this.fetchStatus ) {
					this.changeFilenamePlaceholder( repo, tag );
					this.changeFoldernamePlaceholder( repo );
				}

			},
			changeRepo: function ( el ) {
				var $tag_select = $( '.git-tag' ),
					value = $tag_select.val();
				$tag_select.closest( '.edd-form-group__control' ).addClass( 'edd-git__refreshing' );
				$tag_select.find( 'option' ).remove();
				if ( '' == $( el ).val() || null == $( el ).val() ) {
					$tag_select.append( '<option value="">' + gitUpdater.noTags + '</option>' );
					$tag_select.trigger( 'change' );
					$tag_select.trigger( 'chosen:updated' );
					$tag_select.closest( '.edd-form-group__control' ).removeClass( 'edd-git__refreshing' );
					return false;
				}
				var repo = $( el ).val();
				var that = this;

				$.post( ajaxurl, { action: 'edd_git_get_tags', repo: repo }, function ( response ) {
					if ( 'undefined' == typeof response.error ) {
						_.each( response, function ( tag ) {
							$tag_select.append( '<option value="' + tag + '">' + tag + '</option>' );
						} );
					} else {
						$tag_select.append( '<option value="">' + gitUpdater.noTags + '</option>' );
					}
					$tag_select.val( value );
					$tag_select.trigger( 'change' );
					$tag_select.trigger( 'chosen:updated' );
					$( '.git-tag-spinner' ).hide();
					$( '.git-tag-div' ).fadeIn( 'fast' );
					var status = 'dirty';
					// If we have returned to the original repo AND original tag, we're clean.
					if ( repo == that.currentGitUrl && that.currentTag == $tag_select.val() ) {
						status = 'clean';
					}
					// If we don't have any tag selected, we're none.
					if ( null == $tag_select.val() || '' == $tag_select.val() ) {
						status = 'none';
					}

					$tag_select.closest( '.edd-form-group__control' ).removeClass( 'edd-git__refreshing' );
					that.changeFetchStatus( status );
				} );
			},
			changeFilenamePlaceholder: function ( slug, tag ) {

				if ( null == slug || 'undefined' == typeof slug ) {
					slug = '';
				}
				if ( null == tag || 'undefined' == typeof tag ) {
					tag = '';
				}

				if ( '' != slug && '' != tag ) {
					var placeholder = slug + '-' + tag + '.zip'
				} else {
					var placeholder = '';
				}
				$( '.git-file-name input' ).val( placeholder ).attr( 'placeholder', placeholder );
			},
			changeFoldernamePlaceholder: function ( slug ) {
				if ( 'undefined' != typeof slug || null == slug ) {
					var placeholder = slug;
				} else {
					var placeholder = '';
				}

				var current_value = $( '.git-folder-name input' ).val();

				// Only change the folder name to the repo slug, if one isn't defined.
				if ( ! current_value.length ) {
					$( '.git-folder-name input' ).val( placeholder ).attr( 'placeholder', placeholder );
				}
			},
			changeUseGit: function ( el ) {
				var checked = el.checked ? 1 : 0;
				var that = this;
				var data = {
					action: 'edd_change_use_git',
					post_id: edd_vars.post_id,
					checked: checked,
					product_type: $( '#_edd_product_type' ).val(),
				}

				$( '.edd-git-enable__spinner' ).show().css( 'visibility', 'visible' );
				$.post( ajaxurl, data, function ( response ) {
					$( el ).closest( '.inside' ).html( response.html );
					if ( null == $( '.git-repo' ).val() || '' == $( '.git-repo' ).val() ) {
						$( '.git-file-name input' ).val( '' );
					}
					if ( 1 == checked ) {
						that.useGit = 1;
						that.init();
						that.setUpgradeFile();
					} else {
						that.useGit = 0;
						that.unsetUpgradeFile();
					}
				} );
			},
			fetchFile: function ( e ) {
				var repo_url = $( '.git-repo' ).val();
				var folder_name = $( '.git-folder-name input' ).val();
				var tag = $( '.git-tag' ).val();
				var key = $( this ).parent().parent().parent().data( 'key' );
				var file_name = $( '.git-file-name input' ).val();
				var condition = $( '.git-condition' ).val();
				var that = this;
				$( '.edd-git-update-spinner' ).show();
				$( '.edd-git-update-spinner' ).css( 'visibility', 'visible' );
				$.post( ajaxurl, { action: 'edd_git_update_file', post_id: edd_vars.post_id, condition: condition, file_name: file_name, key: key, version: tag, folder_name: folder_name, repo_url: repo_url }, function ( response ) {
					$( '.edd-git-update-spinner' ).hide();
					console.log( response );
					if ( null == response.errors && 'object' == typeof response ) { // No errors
						$( '#edd_git_error' ).empty();
						that.currentGitUrl = repo_url;
						that.currentTag = tag;
						that.changeFetchStatus( 'clean' );
						that.setUpgradeFile();

						if ( 'checked' == $( '#edd_license_enabled' ).attr( 'checked' ) ) {
							$( '#edd_sl_version' ).val( response.sl_version );
							if ( response.changelog ) {
								if ( typeof tinyMCE != 'undefined' && tinyMCE.get( 'edd_sl_changelog' ) ) {
									tinyMCE.get( 'edd_sl_changelog' ).setContent( response.changelog );
								} else {
									$( '#edd_sl_changelog' ).val( response.changelog );
								}
							}
						}

						$( '.git-file-name input' ).val( response.name );
						$( '#edd_git_file' ).val( response.file );
						$( '#edd_readme_location' ).val( response.readme );
						$( document ).trigger( 'eddGitFileFetched' );
					} else if ( 'undefined' != typeof response.errors ) { // We had an errors
						$( '#edd_git_error' ).html( response.errors );
						$( '.git-update-check' ).hide();
						$( '.git-update-text' ).hide();
						$( '.git-update-none' ).show();
					} else {
						$( '.git-update-check' ).hide();
						$( '.git-update-text' ).hide();
						$( '.git-update-none' ).show();
						console.log( response );
					}

				} );
			},
			updateDownload: function ( e ) {
				if ( $( '#_edd_download_use_git' ).attr( 'checked' ) ) {
					this.setUpgradeFile;
					if ( 'dirty' == this.fetchStatus ) {
						e.preventDefault();
						$( '.edd-git-fetch-prompt' ).eddGitAdminModal( 'open' );
						this.targetButton = e.target;
					}
				}
			},
			fetchAndContinue: function ( e ) {
				var that = this;
				$( '.edd-git-fetch-prompt' ).eddGitAdminModal( 'close' );
				$( document ).on( 'eddGitFileFetched', function () {
					$( that.targetButton ).click();
				} );
				this.fetchFile( e );
			},
			fetchRepos: function ( shouldClear ) {
				$( '.edd-git-fetch-repos' ).siblings( '.edd-form-group__control' ).addClass( 'edd-git__refreshing' );
				$( '.edd-git-fetch-repos .dashicons' ).hide();
				$( '.edd-git-fetch-repos .spinner' ).show();
				$( '.edd-git-fetch-repos .spinner' ).css( 'visibility', 'visible' );
				var data = {
						action: 'edd_git_fetch_repos',
						current_repo: $( '.git-repo' ).val(),
						clear_repositories: shouldClear
					};
				$.post( ajaxurl, data, function ( response ) {
					var options = response.options_html;
					$( 'select.git-repo' ).find( 'option' ).remove();
					$( 'select.git-repo' ).find( 'optgroup' ).remove();
					$( 'select.git-repo' ).append( options );
					$( 'select.git-repo' ).trigger( 'change' );
					$( '.git-repo' ).trigger( 'chosen:updated' );
					$( '.edd-git-fetch-repos .spinner' ).hide();
					$( '.edd-git-fetch-repos .dashicons' ).show();
					$( '.edd-git-fetch-repos' ).siblings( '.edd-form-group__control' ).removeClass( 'edd-git__refreshing' );
				} );
			},
			setUpgradeFile: function ( e ) {
				$( '#edd_sl_upgrade_file' ).find( 'option' ).remove();
				$( '#edd_sl_upgrade_file' ).append( '<option value="0">git</option>' );
				$( '#edd_sl_upgrade_file' ).parent().parent().hide();
			},
			unsetUpgradeFile: function ( e ) {
				$( '#edd_sl_upgrade_file' ).find( 'option' ).remove();
				$( '#edd_sl_upgrade_file' ).parent().parent().show();
			}
		}
	};

	eddGit.editDownload.init();

	$( document ).on( 'click', '#edd-github-auth', function ( e ) {
		e.preventDefault();
		// Authorize GitHub
		eddGit.gitHub.authorize();
	} );

	$( document ).on( 'click', '#edd-github-disconnect', function ( e ) {
		e.preventDefault();
		// Authorize GitHub
		eddGit.gitHub.disconnect();
	} );

	$( document ).on( 'change', '#_edd_download_use_git', function ( e ) {
		eddGit.editDownload.changeUseGit( this );
	} );

	$( document ).on( 'change', '.git-tag', function ( e ) {
		eddGit.editDownload.changeTag( $( this ).val() );
	} );

	$( document ).on( 'change', '.git-repo', function ( e ) {
		eddGit.editDownload.changeRepo( this );
	} );

	$( document ).on( 'click', '.edd-git-update', function ( e ) {
		e.preventDefault();
		eddGit.editDownload.fetchFile( e );
	} );

	$( document ).on( 'click', '#submitpost input', function ( e ) {
		eddGit.editDownload.updateDownload( e );
	} );

	$( document ).on( 'click', '.edd-git-fetch-continue', function ( e ) {
		e.preventDefault();
		eddGit.editDownload.fetchAndContinue( e );
	} );

	$( document ).on( 'click', '.edd-git-fetch-repos', function ( e ) {
		e.preventDefault();
		eddGit.editDownload.fetchRepos( true );
	} );

	$( document ).on( 'change', '#_edd_product_type', function ( e ) {
		if ( 'bundle' === $( this ).val() ) {
			$( '.edd-git-enable' ).hide();
		} else {
			$( '.edd-git-enable' ).show();
		}
	} );

	$( document ).on( 'change', '.git-file-name input, .git-folder-name input', function ( e ) {
		eddGit.editDownload.changeFetchStatus( 'dirty' );
	} );

} )( document, jQuery );
