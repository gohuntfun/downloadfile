<?php
/**
 * Grab repos and tags from GitHub and Bitbucket
 *
 * @package EDD Git Download Updater
 *
 * @since  1.0
 */
class EDD_GIT_Download_Updater_Repos {
	/**
	 * Fetch our repos from either our cache or BB/GH
	 *
	 * @since  1.0
	 *
	 * @return array $repos
	 */
	public function fetch_repos() {
		$repos = get_transient( 'edd_git_repos' );
		if ( false !== $repos ) {
			return $repos;
		}
		$repos = $this->fetch_from_github();
		$repos = $this->fetch_from_bitbucket( $repos );

		set_transient( 'edd_git_repos', $repos, HOUR_IN_SECONDS );

		return $repos;
	}

	/**
	 * Fetches repositories from Bitbucket.
	 *
	 * @since 1.2
	 * @param array $repos
	 * @return array
	 */
	private function fetch_from_bitbucket( $repos ) {
		if ( ! defined( 'EDD_GIT_BB_USER' ) || ! defined( 'EDD_GIT_BB_PASSWORD' ) ) {
			return $repos;
		}
		$token        = base64_encode( EDD_GIT_BB_USER . ':' . EDD_GIT_BB_PASSWORD );
		$headers      = array(
			'Authorization' => "Basic {$token}",
			'Connection'    => 'keep-alive',
		);
		$body         = new stdClass();
		$body->values = true;
		$page         = 1;
		$slug         = '';
		while ( ! empty( $body->values ) ) {
			$api_url  = add_query_arg(
				array(
					'page'    => $page,
					'pagelen' => 100,
				),
				'https://api.bitbucket.org/2.0/user/permissions/repositories'
			);
			$response = wp_safe_remote_get(
				$api_url,
				array(
					'headers' => $headers,
				)
			);
			$body     = json_decode( wp_remote_retrieve_body( $response ) );
			if ( empty( $body ) || empty( $body->values ) ) {
				break;
			}

			$organized_bb_repos = array();
			foreach ( $body->values as $repository_object ) {
				if ( empty( $repository_object->repository ) ) {
					continue;
				}

				$repo_slug  = $repository_object->repository->full_name;
				$slug_parts = explode( '/', $repo_slug );
				$owner      = $slug_parts[0];

				if ( ! array_key_exists( $owner, $organized_bb_repos ) ) {
					$organized_bb_repos[ $owner ] = array();
				}

				$organized_bb_repos[ $owner ][ $repository_object->repository->links->html->href ] = $slug_parts[1];
			}

			foreach ( $organized_bb_repos as $owner => $bb_repo ) {
				foreach ( $bb_repo as $html_url => $repo_slug ) {
					if ( $slug !== $owner ) {
						if ( ! empty( $slug ) ) {
							$repos['bb'][] = array( 'close' );
						}
						$slug          = $owner;
						$repos['bb'][] = array( 'open' => $owner );
					}
					$repos['bb'][ $html_url ] = $repo_slug;
				}
			}
			$page++;
		}

		return $repos;
	}

	/**
	 * Fetches the repositories from GitHub.
	 *
	 * @since 1.2
	 * @param array $repos
	 * @return array
	 */
	private function fetch_from_github( $repos = array() ) {
		$edd_settings    = edd_get_settings();
		$gh_access_token = isset( $edd_settings['gh_access_token'] ) ? $edd_settings['gh_access_token'] : '';
		// Get a list of our GH repos.
		if ( empty( $gh_access_token ) ) {
			return $repos;
		}
		$headers = array(
			'Authorization' => "token {$gh_access_token}",
		);
		$body    = true;
		$page    = 1;
		$owner   = '';
		while ( ! empty( $body ) ) {
			$url      = add_query_arg(
				array(
					'per_page' => 100,
					'page'     => $page,
				),
				'https://api.github.com/user/repos'
			);
			$response = wp_safe_remote_get(
				$url,
				array(
					'sslverify' => false,
					'headers'   => $headers,
				)
			);

			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $body ) ) {
				foreach ( $body as $repo ) {
					if ( $owner !== $repo['owner']['login'] ) {
						if ( ! empty( $owner ) ) {
							$repos['gh'][] = array( 'close' );
						}
						$owner         = $repo['owner']['login'];
						$repos['gh'][] = array( 'open' => $owner );
					}
					$repos['gh'][ $repo['html_url'] ] = $repo['name'];
				}
			}
			$page++;
		}

		return $repos;
	}

	/**
	 * Grab out tags from GH or BB
	 *
	 * @since  1.0
	 *
	 * @param  string $repo_url URL of our repo.
	 * @return array $tags
	 */
	public function fetch_tags( $repo_url ) {
		if ( false !== strpos( $repo_url, 'bitbucket.org' ) ) { // Bitbucket url.
			$replace = array( 'https://bitbucket.org/', 'api/2.0/repositories/' );
			$function = 'bb_get_tags';
		} else { // GitHub url.
			$replace = 'https://github.com/';
			$function = 'gh_get_tags';
		}

		$slug = str_replace( $replace, '', $repo_url );

		return $this->$function( $slug );
	}

	/**
	 * Fetch our tags from GitHub
	 *
	 * @since  1.0
	 *
	 * @param  string $tag_url URL of our repo.
	 * @return array   $tags
	 */
	public function gh_get_tags( $tag_url ) {
		if ( empty( $tag_url ) ) {
			return array();
		}
		$edd_settings    = edd_get_settings();
		$gh_access_token = isset( $edd_settings['gh_access_token'] ) ? $edd_settings['gh_access_token'] : '';
		if ( empty( $gh_access_token ) ) {
			return array();
		}
		$headers = array(
			'Authorization' => "token {$gh_access_token}",
		);

		$tag_url     = "https://api.github.com/repos/{$tag_url}/tags";
		$get_tags    = wp_safe_remote_get(
			$tag_url,
			array(
				'sslverify' => false,
				'headers'   => $headers,
			)
		);
		$tags        = json_decode( wp_remote_retrieve_body( $get_tags ), true );
		$return_tags = array();
		if ( is_array( $tags ) && ! empty( $tags ) && ! isset( $tags['message'] ) ) {
			foreach ( $tags as $tag ) {
				$return_tags[] = $tag['name'];
			}
		} else {
			$return_tags['error'] = __( 'Could not find any tags for repository.', 'edd-git-download-updater' );
		}

		return $return_tags;
	}

	/**
	 * Fetch our tags from Bitbucket
	 *
	 * @since  1.0
	 *
	 * @param  string $tag_url URL of our repo.
	 * @return array $tags
	 */
	public function bb_get_tags( $tag_url ) {
		$token       = base64_encode( EDD_GIT_BB_USER . ':' . EDD_GIT_BB_PASSWORD );
		$api_url     = "https://api.bitbucket.org/2.0/repositories/{$tag_url}/refs/tags/?pagelen=100";
		$headers     = array(
			'Authorization' => "Basic {$token}",
			'Connection'    => 'keep-alive',
		);
		$response    = wp_safe_remote_get(
			$api_url,
			array(
				'headers' => $headers,
			)
		);
		$tags        = json_decode( wp_remote_retrieve_body( $response ) );
		$return_tags = array();
		if ( ! empty( $tags->values ) ) {
			foreach ( $tags->values as $tag_object ) {
				$return_tags[] = $tag_object->name;
			}
		} else {
			$return_tags['error'] = __( 'Could not find any tags for repository.', 'edd-git-download-updater' );
		}

		return $return_tags;
	}

	/**
	 * Return our current tag
	 *
	 * @since  1.0
	 *
	 * @param  integer $download_id The Download ID to get the current tag of.
	 * @return string   $version
	 */
	public function get_current_tag( $download_id ) {
		$version = false;
		$files = get_post_meta( $download_id, 'edd_download_files', true );
		if ( empty( $files ) ) {
			return $version;
		}

		foreach ( $files as $file ) {
			$version = isset( $file['git_version'] ) ? $file['git_version'] : '';

			if ( ! empty( $version ) ) {
				break;
			}
		}

		return $version;
	}

	/**
	 * Return our current repo URL
	 *
	 * @since  1.0
	 *
	 * @param  integer $download_id The download ID to get the current repo URL for.
	 * @return string $url
	 */
	public function get_current_repo_url( $download_id ) {
		$url = false;
		$files = get_post_meta( $download_id, 'edd_download_files', true );
		if ( empty( $files ) ) {
			return $url;
		}

		foreach ( $files as $file ) {
			$url = isset( $file['git_url'] ) ? $file['git_url'] : '';

			if ( ! empty( $url ) ) {
				break;
			}
		}

		return $url;
	}

}
