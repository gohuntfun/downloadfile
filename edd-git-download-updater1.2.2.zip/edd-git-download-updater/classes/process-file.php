<?php
/**
 * Process our fetched file
 *
 * @package EDD Git Download Updater
 * @since  1.0
 */
class EDD_GIT_Download_Updater_Process_File {

	/**
	 * The current instance of this class.
	 *
	 * @var EDD_GIT_Download_Updater
	 */
	private $instance;

	/**
	 * The download ID
	 *
	 * @var int
	 */
	private $download_id;

	/**
	 * The tag to process
	 *
	 * @var string
	 */
	private $version;

	/**
	 * The repository URL
	 *
	 * @var string
	 */
	private $url;

	/**
	 * The repository URL
	 *
	 * @var string
	 */
	private $repo_url;

	/**
	 * The file key for the EDD Files array
	 *
	 * @var int
	 */
	private $file_key;

	/**
	 * The folder name to be used when the archive is unpacked
	 *
	 * @var string
	 */
	private $original_foldername;

	/**
	 * The file name that should be used when downloading the archive
	 *
	 * @var string
	 */
	private $original_filename;

	/**
	 * The temporary directory where we are storing things while we make the proper folder and archive names.
	 *
	 * @var string
	 */
	private $tmp_dir;

	/**
	 * The final file name we're going to be using when making the new archive
	 *
	 * @var string
	 */
	private $file_name;

	/**
	 * The changelog for the product, read from the readme.txt from the downloaded tag
	 *
	 * @var string
	 */
	private $changelog;

	/**
	 * The file condition
	 *
	 * @var string
	 */
	private $condition;

	/**
	 * The URL and Path of the EDD file directory for uploaded files
	 *
	 * @var array
	 */
	private $edd_dir;

	/**
	 * The version we're going to assign to the Software Licensing version field
	 *
	 * @var string
	 */
	private $sl_version;

	/**
	 * The git repository temporary value
	 *
	 * @var string
	 */
	private $git_repo;

	/**
	 * A holder for any errors that occur
	 *
	 * @var array
	 */
	private $errors;

	/**
	 * The subdirectory of our unpacked original archive
	 *
	 * @var string
	 */
	private $sub_dir;

	/**
	 * The folder name that will be used when the final archive is unpacked
	 *
	 * @var string
	 */
	private $folder_name;

	/**
	 * The git provider to use
	 *
	 * @var string
	 */
	private $source;

	/**
	 * EDD_GIT_Download_Updater_Process_File constructor.
	 *
	 * @param EDD_GIT_Download_Updater $instance The instance of this class.
	 */
	public function __construct( $instance ) {
		$this->instance = $instance;
	}

	/**
	 * Process our file
	 *
	 * @since  1.0
	 *
	 * @param int    $post_id     The download ID to work with.
	 * @param string $version     The tag of the repo to download.
	 * @param string $repo_url    The URL to the repository.
	 * @param int    $key         The file key for the EDD files array.
	 * @param string $folder_name The folder name that should be used when the final archive is unpacked.
	 * @param string $file_name   The file name for the archive when downloaded.
	 *
	 * @return array
	 * @throws Exception When anything but a 200 request is received while processing the file.
	 */
	public function process( $post_id, $version, $repo_url, $key, $folder_name, $file_name ) {
		// OK, we're authenticated: we need to find and save the data.
		$this->instance->download_id = $post_id;
		$this->instance->version = $version;
		$this->instance->url = $repo_url;
		$this->instance->repo_url = $repo_url;
		$this->instance->file_key = $key;
		$this->instance->original_filename = $file_name;
		$this->instance->original_foldername = $folder_name;

		// Include our zip archive utility.
		require_once( EDD_GIT_PLUGIN_DIR . 'includes/flx-zip-archive.php' );

		// Setup our initial variables.
		$this->set_url();
		$this->set_foldername( $folder_name );
		$this->set_tmp_dir();
		$this->set_edd_dir();
		$this->set_filename( $file_name );

		// Grab our zip file.
		$zip_path = $this->fetch_zip();

		if ( ! $zip_path ) {
			// If we bailed during the fetch_zip function, stop processing update.
			die();
		}
		// Unzip our file to a new temporary directory.
		$new_dir = $this->unzip( $zip_path );

		// Create our new zip file.
		$zip = $this->zip( $new_dir, $this->instance->tmp_dir . $this->instance->file_name );

		// Move our temporary zip to the proper EDD folder.
		$new_zip           = $this->move_zip( $zip );
		$new_zip['readme'] = $this->copy_readme_file( $new_dir );

		// Remove our temporary files.
		$this->remove_dir( $this->instance->tmp_dir );

		// Reset our temporary directory.
		$this->set_tmp_dir();

		// Update our file with the new zip location.
		$this->update_files( $new_zip['url'] );

		return $new_zip;
	}

	/**
	 * Update the download's changelog from our grabbed readme.txt
	 *
	 * @since 1.0
	 *
	 * @param string $new_dir The directory to look in to grab the readme.txt file for.
	 * @return void
	 */
	public function update_changelog( $new_dir ) {
		$path = trailingslashit( $new_dir ) . 'readme.txt';
		if ( ! file_exists( $path ) ) {
			return;
		}
		if ( ! defined( 'EDD_SL_PLUGIN_DIR' ) ) {
			return;
		}
		$file_contents = file_get_contents( $path );
		if ( ! $file_contents ) {
			return;
		}

		include_once EDD_SL_PLUGIN_DIR . 'includes/classes/class-sl-parser.php';
		if ( ! class_exists( 'EDD_SL_Readme_Parser' ) ) {
			return;
		}
		$parser  = new EDD_SL_Readme_Parser( $file_contents );
		$content = $parser->parse_data();
		if ( isset( $content['sections']['changelog'] ) ) {
			$changelog = wp_kses_post( $content['sections']['changelog'] );
			update_post_meta( $this->instance->download_id, '_edd_sl_changelog', $changelog );
		}
	}

	/**
	 * Retrieves the changelog text from the readme.txt file.
	 *
	 * @since 1.2
	 * @param string $readme_url The URL for the readme.txt file.
	 * @return void
	 */
	private function set_changelog_text( $readme_url ) {
		if ( ! $readme_url ) {
			return;
		}

		$content = _edd_sl_readme_parse( $readme_url );
		if ( isset( $content['sections']['changelog'] ) ) {
			$this->instance->changelog = wp_kses_post( $content['sections']['changelog'] );
		}
	}

	/**
	 * If Software Licensing is active, copies the repository readme file to the
	 * EDD directory.
	 *
	 * @since 1.2
	 * @param string $new_dir
	 * @return string|boolean
	 */
	private function copy_readme_file( $new_dir ) {
		if ( ! function_exists( '_edd_sl_readme_parse' ) ) {
			return false;
		}
		$url = trailingslashit( $new_dir ) . 'readme.txt';
		if ( ! file_exists( $url ) ) {
			return false;
		}
		// Get upload path and URL for readme file.
		remove_filter( 'upload_dir', 'edd_set_upload_dir' );
		$upload_dir = wp_upload_dir();
		add_filter( 'upload_dir', 'edd_set_upload_dir' );
		$upload_path = trailingslashit( $upload_dir['path'] );
		$upload_url  = trailingslashit( $upload_dir['url'] );
		$readme_path = "{$upload_path}{$this->instance->folder_name}-readme.{$this->instance->version}.txt";
		$readme_url  = "{$upload_url}{$this->instance->folder_name}-readme.{$this->instance->version}.txt";

		// Copy readme file to EDD upload directory.
		$readme = copy( $url, $readme_path );
		if ( ! $readme ) {
			return false;
		}
		$this->set_changelog_text( $readme_url );

		$edd_settings = edd_get_settings();
		if ( empty( $edd_settings['edd_sl_readme_parsing'] ) ) {
			unlink( $readme_path );
			return false;
		}

		return $readme_url;
	}

	/**
	 * Update our download files post meta
	 *
	 * @since 1.0
	 *
	 * @param string $new_zip The new archive file for the EDD Files array.
	 *
	 * @return void
	 */
	public function update_files( $new_zip ) {
		// $files = get_post_meta( $this->instance->download_id, 'edd_download_files', true );
		$files = array();
		$files[ $this->instance->file_key ]['git_version']        = $this->instance->version;
		$files[ $this->instance->file_key ]['git_url']            = $this->instance->repo_url;
		$files[ $this->instance->file_key ]['git_folder_name']    = $this->instance->original_foldername;
		$files[ $this->instance->file_key ]['file']               = $new_zip;
		$files[ $this->instance->file_key ]['name']               = ! empty( $this->instance->file_name ) ? $this->instance->file_name : basename( $new_zip );
		$files[ $this->instance->file_key ]['condition']          = $this->instance->condition;
		$files[ $this->instance->file_key ]['attachment_id']      = 0;

		update_post_meta( $this->instance->download_id, 'edd_download_files', $files );
		if ( 0 === strpos( $this->instance->version, 'v' ) ) {
			$this->instance->sl_version = substr( $this->instance->version, 1 );
		} else {
			$this->instance->sl_version = $this->instance->version;
		}
		update_post_meta( $this->instance->download_id, '_edd_sl_version', $this->instance->sl_version );
	}

	/**
	 * Move our zip file to the EDD uploads directory
	 *
	 * @since 1.0
	 *
	 * @param string $zip The zip file to move.
	 *
	 * @return array $new_zip
	 */
	public function move_zip( $zip ) {
		// Get upload path and URL for zip file.
		$edd_dir     = trailingslashit( $this->instance->edd_dir['path'] );
		$edd_url     = trailingslashit( $this->instance->edd_dir['url'] );
		$upload_path = apply_filters( 'edd_git_upload_path', $edd_dir . $this->instance->file_name );
		$upload_url  = apply_filters( 'edd_git_upload_url', $edd_url . $this->instance->file_name );

		// Copy zip file to EDD upload directory.
		copy( $zip, $upload_path );

		// Delete temporary zip file.
		unlink( $zip );

		// Prepare zip file path and URL.
		$new_zip = array(
			'path' => $upload_path,
			'url'  => $upload_url,
		);

		/**
		 * Fires after zip file has been moved to EDD uploads directory.
		 *
		 * @since Unknown
		 *
		 * @param array  $new_zip {
		 *    Path and URL to zip file.
		 *
		 *    @param string $path Path to zip file.
		 *    @param string $url  URL to zip file.
		 * }
		 * @param string $git_repo Name of git repo.
		 */
		do_action( 'edd_git_zip_saved', $new_zip, $this->instance->git_repo );

		return $new_zip;
	}

	/**
	 * Set our temporary directory. Create it if it doesn't exist.
	 *
	 * @since 1.0
	 * @return void
	 */
	public function set_tmp_dir() {
		$tmp_dir = wp_upload_dir();
		$tmp_dir = trailingslashit( $tmp_dir['basedir'] ) . 'edd-git-tmp/';
		$tmp_dir = apply_filters( 'edd_git_zip_path', $tmp_dir );

		if ( ! is_dir( $tmp_dir ) ) {
			mkdir( $tmp_dir );
		}

		// $tmp_dir will always have a trailing slash.
		$this->instance->tmp_dir = trailingslashit( $tmp_dir );
	}

	/**
	 * Set our git URL. Also sets whether we are working from GitHub or Bitbucket.
	 *
	 * @since 1.0
	 */
	public function set_url() {
		$edd_settings = get_option( 'edd_settings' );

		$url = trailingslashit( $this->instance->url );

		// Change some of the data for Bitbucket.
		$url = str_replace( 'api/2.0/repositories/', '', $url );

		$tmp = explode( '/', $url );

		$user = $tmp[3];
		$repo = $tmp[4];

		if ( 'bitbucket.org' == $tmp[2] ) {
			// Add an error and bail if our BB user and password aren't set.
			if ( ! defined( 'EDD_GIT_BB_USER' ) || ! defined( 'EDD_GIT_BB_PASSWORD' ) ) {
				// Add errors.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => '404',
					'msg'   => __( 'Cannot access repository.', 'edd-git-download-updater' ),
				);

				// Bail.
				return false;
			}
			$url_part = 'get/' . $this->instance->version . '.zip';
			$url .= $url_part;

			$this->instance->source = 'bitbucket';
		} else if ( 'github.com' == $tmp[2] ) {
			$access_token = isset( $edd_settings['gh_access_token'] ) ? $edd_settings['gh_access_token'] : '';
			if ( empty( $access_token ) ) { // If we don't have an oAuth access token, add error and bail.
				// Add Error.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => '404',
					'msg'   => __( 'Cannot access repository.', 'edd-git-download-updater' ),
				);

				// Bail.
				return false;
			} else {
				$url = "https://api.github.com/repos/{$user}/{$repo}/zipball/{$this->instance->version}";
			}
			$this->instance->source = 'github';
		} else {
			// Throw an error.
			$this->instance->errors[ $this->instance->file_key ] = array(
				'error' => '404',
				'msg'   => __( 'Cannot access repository.', 'edd-git-download-updater' ),
			);

			// Bail.
			return false;
		}

		$this->instance->git_repo = $tmp[4];

		$this->instance->url = apply_filters( 'edd_git_repo_url', $url );
		return $this->instance->url;
	}

	/**
	 * Set our clean zip file name
	 *
	 * @since 1.0
	 *
	 * @param string $file_name The file name to set.
	 *
	 * @return void
	 */
	public function set_filename( $file_name ) {
		$this->instance->file_name = ! empty( $file_name ) ? $file_name : $this->instance->git_repo . '-' . $this->instance->version . '.zip';

		$this->instance->file_name = apply_filters( 'edd_git_download_file_name', $this->instance->file_name, $this->instance->download_id, $this->instance->file_key );
	}

	/**
	 * Set the name of our folder that should go inside our new zip.
	 *
	 * @since 1.0
	 *
	 * @param string $folder_name The folder name to set.
	 *
	 * @return void
	 */
	public function set_foldername( $folder_name ) {
		$this->instance->folder_name = ! empty( $folder_name ) ? $folder_name : sanitize_title( $this->instance->git_repo );
	}

	/**
	 * Grab the zip file from git and store it in our temporary directory.
	 *
	 * @since 1.0
	 *
	 * @return string $zip_path
	 * @throws Exception In the event of an HTTP failure, this will thrown an exception.
	 */
	public function fetch_zip() {
		$zip_path = $this->instance->tmp_dir . $this->instance->file_name;

		if ( 'bitbucket' == $this->instance->source ) {
			if ( ! defined( 'EDD_GIT_BB_USER' ) || ! defined( 'EDD_GIT_BB_PASSWORD' ) ) { // If BB credentials aren't set, add error and bail.
				// Add Errors.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => '404',
					'msg'   => __( 'Missing Bitbucket credentials.', 'edd-git-download-updater' ),
				);

				// Bail.
				return false;
			}

			$token    = base64_encode( EDD_GIT_BB_USER . ':' . EDD_GIT_BB_PASSWORD );
			$headers  = array(
				'Authorization' => "Basic {$token}",
				'Connection'    => 'keep-alive',
			);
			$response = wp_safe_remote_get(
				$this->instance->url,
				array(
					'headers' => $headers,
				)
			);
			if ( is_wp_error( $response ) ) {
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => 401,
					'msg'   => __( 'Unable to retrieve .zip file.', 'edd-git-download-updater' ) . ' ' . $response->get_error_message(),
				);
				// Bail.
				return false;
			}

			$content_type = wp_remote_retrieve_header( $response, 'content-type' );
			// Bitbucket returns a string like "application/zip; charset=utf-8"
			if ( false === strpos( $content_type, 'application/zip' ) ) {
				// Add error.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => 401,
					'msg'   => __( 'Invalid content type.', 'edd-git-download-updater' ),
				);
				// Bail.
				return false;
			}

			$fp = fopen( $zip_path, 'w' );
			fwrite( $fp, wp_remote_retrieve_body( $response ) );
		} else {
			$edd_settings = get_option( 'edd_settings' );
			$gh_access_token = isset( $edd_settings['gh_access_token'] ) ? $edd_settings['gh_access_token'] : '';

			if ( empty( $gh_access_token ) ) { // If we don't have a GitHub oAuth access token, add error and bail.
				// Add Errors.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => '404',
					'msg'   => __( 'Not connected to GitHub.', 'edd-git-download-updater' ),
				);
				// Bail.
				return false;
			}
			$headers  = array(
				'Authorization' => "token {$gh_access_token}",
			);
			$response = wp_safe_remote_get(
				$this->instance->url,
				array(
					'timeout' => 15000,
					'headers' => $headers,
				)
			);
			if ( is_wp_error( $response ) ) {
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => 401,
					'msg'   => __( 'Unable to retrieve .zip file.', 'edd-git-download-updater' ) . ' ' . $response->get_error_message(),
				);
				// Bail.
				return false;
			}

			$content_type = wp_remote_retrieve_header( $response, 'content-type' );
			if ( 'application/zip' !== $content_type ) {
				// Add error.
				$this->instance->errors[ $this->instance->file_key ] = array(
					'error' => 401,
					'msg'   => __( 'Invalid content type.', 'edd-git-download-updater' ),
				);
				// Bail.
				return false;
			}

			$fp = fopen( $zip_path, 'w' );
			fwrite( $fp, $response['body'] );
		}

		do_action( 'edd_git_zip_fetched', $zip_path, $this->instance->git_repo );

		return $zip_path;
	}

	/**
	 * Unzip our file into a new temporary folder.
	 *
	 * @since 1.0
	 *
	 * @param string $zip_path The file path.
	 *
	 * @return string $new_dir
	 */
	public function unzip( $zip_path ) {
		if ( is_dir( trailingslashit( $this->instance->tmp_dir . $this->instance->folder_name ) ) ) {
			$this->remove_dir( trailingslashit( $this->instance->tmp_dir . $this->instance->folder_name ) );
		}
		$zip = new ZipArchive();
		$zip->open( $zip_path );
		$zip->extractTo( $this->instance->tmp_dir );
		$zip->close();
		$this->set_sub_dir( $this->instance->tmp_dir );

		$new_dir = rename( $this->instance->tmp_dir . $this->instance->sub_dir, $this->instance->tmp_dir . $this->instance->folder_name );

		if ( ! $new_dir ) {
			return false;
		}

		$new_dir = $this->instance->tmp_dir . $this->instance->folder_name;
		$this->set_sub_dir( $this->instance->tmp_dir );
		unlink( $this->instance->tmp_dir . $this->instance->file_name );

		return $new_dir;
	}

	/**
	 * Zip our directory and return the path to the zip file.
	 *
	 * @since 1.0
	 *
	 * @param string $dir The directory to compress.
	 * @param string $destination The destination for the compressed file.
	 *
	 * @return string $destination
	 */
	public function zip( $dir, $destination ) {

		// Don't forget to remove the trailing slash.

		$the_folder    = $dir;
		$zip_file_name = $destination;

		$za = new FlxZipArchive();

		$res = $za->open( $zip_file_name, ZipArchive::CREATE );

		if ( true === $res ) {
			$za->addDir( $the_folder, basename( $the_folder ) );
			$za->close();
		} else {
			echo 'Could not create a zip archive';
		}

		return $destination;
	}

	/**
	 * Delete tmp directory and all contents
	 *
	 * @since 1.0
	 *
	 * @param string $dir The directory to remove.
	 *
	 * @return void
	 */
	public function remove_dir( $dir ) {
		foreach ( scandir( $dir ) as $file ) {
			if ( '.' === $file || '..' === $file ) {
				continue;
			}

			$dir = trailingslashit( $dir );
			if ( is_dir( $dir . $file ) ) {
				$this->remove_dir( $dir . $file );
			} else {
				unlink( $dir . $file );
			}
		}
		rmdir( $dir );
	}

	/**
	 * Get our newly unzipped subdirectory name.
	 *
	 * @since 1.0
	 *
	 * @param string $tmp_dir The temp dir.
	 *
	 * @return void|array
	 */
	public function set_sub_dir( $tmp_dir ) {
		$dir_array = array();
		// Bail if we weren't sent a directory.
		if ( ! is_dir( $tmp_dir ) ) {
			return $dir_array;
		}

		$dh = opendir( $tmp_dir );
		if ( $dh ) {
			while ( ( $file = readdir( $dh ) ) !== false ) {
				if ( '.' == $file || '..' == $file ) {
					continue;
				}

				if ( strpos( $file, $this->instance->git_repo ) !== false ) {
					if ( is_dir( $tmp_dir . '/' . $file ) ) {
						$this->instance->sub_dir = $file;
						break;
					}
				}
			}
			closedir( $dh );
		}

	}

	/**
	 * Set our EDD uploads directory.
	 *
	 * @since 1.0
	 * @return void
	 */
	public function set_edd_dir() {
		add_filter( 'upload_dir', 'edd_set_upload_dir' );
		$upload_dir = wp_upload_dir();
		wp_mkdir_p( $upload_dir['path'] );
		$this->instance->edd_dir = $upload_dir;
	}
}
